# stn_advancedmoneywash
This is the best release of my money laundering script with discord logs, police alerts and much more.
FORUM LINK -

## Dependencies:-

1.es_extended   --> https://github.com/esx-framework/esx-legacy

2.rprogress     --> https://github.com/Mobius1/rprogress

## Installation:-

1.Clone or download the folder into your resources folder.

2.Enter ensure stn_advancedmoneywash in your server.cfg.

3.Start your server.

## Features:-

1.Best Money Wash/ Laundering Script.

2.Discord Logs Integration.

3.Integrated Notification system.

4.Shows Cop Alerts.

5.Shows blip to police officers in the minimap.

6.Uses Configurable taxation system.

7.Easy to configure.

## Credits:-

1.Notification System - https://github.com/btwlouis/notification

2.rProgress Progressbar System - https://github.com/Mobius1/rprogress
