Config 					= {}

Config.Locale 			= 'en'


Config.DrawDistance 	= 10


Config.CopsRequired = 0


Config.CooldownMinutes = 10


Config.ItemName = 'blacktoken'


Config.Location = {x = -177.56303405762, y = 6550.8951171875, z = 11.09804058075}


Config.BlipUpdateTime = 3000


Config.Heading = 180


Config.Headingjobped = 180


Config.AllowedJob = "any"


Config.Taxation = 0.50


Config.JobPed1 = {x = 946.24780273438, y = -3086.8168945313, z = 5.900764465332}
Config.JobPed2 = {x = 945.24780273438, y = -3086.4168945313, z = 5.900764465332}
Config.JobPed3 = {x = 947.24780273438, y = -3086.4168945313, z = 5.900764465332}

Config.Webhook = "https://discord.com/api/webhooks/912665408945934398/WezsXFYS-NtvluqNUhuRjHsGYyO6Rnx4YUtjNIQcyAnPaJQU8RV0Q49dzWWXDCFWdiNE"


Config.Webhookname = 'Zetta64 Logger' -- Name of the WebHook


Config.WebhookLogo = 'https://c.file.glass/HDgu1bZLqt.png' -- Avatar of the WebHook

Locales['en'] = {
	['you_have_washed'] 		= 'You have washed $',
	['dirty_money'] 			= 'dirty money.',
	['you_have_received'] 		= 'You received a total of $',
	['clean_money'] 			= 'Clean money',
	['invalid_amount']			= 'You have entered an invalid amount',
	['press_menu'] 				= 'Press ~INPUT_CONTEXT~ to ~r~ to start the dealing.~s~',
	['press_menu_start'] 		= 'Press ~INPUT_CONTEXT~ to ~r~ to talk to the dealer.~s~',
	['no'] 						= 'No',
	['wash_money']				= 'Wash Money',
	['washed_menu']				= 'Money Washing',
	['wash_money_amount']		= 'Amount of money to wash',
	['success']                 = 'You can reach my boss.Location has been marked in your gps.Be careful with the police!',
	['not_cop']                 = 'Not enough cops in city.',
	['already_active']          = 'Already a money laundering is going on',
	['cooldown']                = 'The process is in a cooldown',
    ['already_item']            = 'You already have the item',
	['no_item']                 = 'You do not have the required item'

}

